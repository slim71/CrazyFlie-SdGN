Vicon DataStream SDK
====================

This is the python version of the Vicon DataStream SDK. The API has been changed from the C++/.NET 
version to make it more familiar to Python users. All documentation is contained inline within the
module

